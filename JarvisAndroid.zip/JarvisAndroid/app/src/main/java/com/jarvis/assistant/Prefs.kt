package com.jarvis.assistant

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Settings and API keys, encrypted at rest with a key held in the Android Keystore. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        sp = EncryptedSharedPreferences.create(
            ctx, "jarvis_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    private fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    private fun put(k: String, v: String) = sp.edit().putString(k, v.trim()).apply()

    var geminiKey: String
        get() = s("gemini")
        set(v) = put("gemini", v)

    var elevenKey: String
        get() = s("eleven")
        set(v) = put("eleven", v)

    var voiceId: String
        get() = s("voice_id")
        set(v) = put("voice_id", v)

    var userName: String
        get() = s("user_name", "Sir")
        set(v) = put("user_name", v)

    var assistantName: String
        get() = s("assistant_name", "Jarvis")
        set(v) = put("assistant_name", v)

    var wakeWord: String
        get() = s("wake_word", "jarvis")
        set(v) = put("wake_word", v.lowercase())

    /** Speech recognition language tag, e.g. "en-US" or "id-ID". Empty = phone default. */
    var sttLang: String
        get() = s("stt_lang")
        set(v) = put("stt_lang", v)

    /** Fallback (system) voice. */
    var ttsLocale: String
        get() = s("tts_locale", "en-GB")
        set(v) = put("tts_locale", v)

    var ttsVoiceName: String
        get() = s("tts_voice")
        set(v) = put("tts_voice", v)

    var ttsPitch: Float
        get() = s("tts_pitch", "0.82").toFloatOrNull() ?: 0.82f
        set(v) = put("tts_pitch", v.toString())

    var ttsRate: Float
        get() = s("tts_rate", "1.0").toFloatOrNull() ?: 1.0f
        set(v) = put("tts_rate", v.toString())

    var handsFree: Boolean
        get() = s("hands_free", "0") == "1"
        set(v) = put("hands_free", if (v) "1" else "0")

    fun elevenReady() = elevenKey.isNotBlank() && voiceId.isNotBlank()
}
