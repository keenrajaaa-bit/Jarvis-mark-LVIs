package com.jarvis.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Keeps the last 60 notifications in memory (never on disk) so Jarvis can read them out when asked. */
class JarvisNotifications : NotificationListenerService() {

    data class Item(val app: String, val title: String, val text: String, val time: Long)

    companion object {
        private val buf = ArrayDeque<Item>()
        @Volatile var instance: JarvisNotifications? = null

        fun recent(n: Int): List<Item> = synchronized(buf) { buf.toList().takeLast(n).reversed() }
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        synchronized(buf) {
            buf.addLast(Item(app, title, text, sbn.postTime))
            while (buf.size > 60) buf.removeFirst()
        }
    }
}
