package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

/** Starts the foreground service (needs the microphone permission first). */
fun startJarvis(ctx: Context) {
    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
    try {
        ContextCompat.startForegroundService(ctx, Intent(ctx, JarvisService::class.java))
    } catch (e: Exception) {
        Engine.note("Could not start the background service: ${e.message}")
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startJarvis(this)
        setContent {
            JarvisTheme {
                var screen by remember { mutableStateOf("hud") }
                BackHandler(enabled = screen != "hud") { screen = "hud" }
                when (screen) {
                    "settings" -> SettingsScreen(onBack = { screen = "hud" })
                    "access" -> AccessScreen(onBack = { screen = "hud" })
                    else -> HudScreen(onSettings = { screen = "settings" }, onAccess = { screen = "access" })
                }
                ConfirmDialog()
            }
        }
    }
}
