package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    fun get(url: String): String {
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code} from ${r.request.url.host}")
            return r.body?.string().orEmpty()
        }
    }
}

/** One place for every Gemini call: a short model ladder, timeouts, and cooldowns for failing models. */
object Gemini {
    private val ladder = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite")
    private val restUntil = HashMap<String, Long>()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private fun post(model: String, key: String, body: JSONObject): Pair<Int, String> {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody(JSON))
            .build()
        Net.client.newCall(req).execute().use { r -> return r.code to r.body?.string().orEmpty() }
    }

    suspend fun generate(body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val key = Prefs.geminiKey
        if (key.isBlank()) {
            throw IOException("No Gemini API key. Open Settings and paste one from aistudio.google.com/apikey.")
        }
        val now = System.currentTimeMillis()
        val candidates = ladder.filter { (restUntil[it] ?: 0L) <= now }.ifEmpty { ladder }
        var last: IOException? = null
        for (model in candidates) {
            val (code, text) = try {
                post(model, key, body)
            } catch (e: IOException) {
                last = e
                restUntil[model] = System.currentTimeMillis() + 2 * 60_000L
                continue
            }
            if (code in 200..299) return@withContext JSONObject(text)
            if (code == 400 || code == 401 || code == 403) {
                throw IOException("Gemini $code: ${text.take(240)}")
            }
            val rest = when (code) {
                429 -> 5 * 60_000L
                404 -> 6 * 3_600_000L
                else -> 30 * 60_000L
            }
            restUntil[model] = System.currentTimeMillis() + rest
            last = IOException("Gemini $code: ${text.take(240)}")
        }
        throw last ?: IOException("No Gemini model answered.")
    }

    fun textOf(res: JSONObject): String {
        val parts = res.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought")) sb.append(p.optString("text"))
        }
        return sb.toString()
    }

    /** One-shot call, optionally with Google Search grounding or an inline JPEG. */
    suspend fun oneShot(
        prompt: String,
        system: String? = null,
        imageB64: String? = null,
        search: Boolean = false,
    ): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (imageB64 != null) {
            parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", imageB64)))
        }
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
        if (system != null) {
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        }
        if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return textOf(generate(body))
    }
}
