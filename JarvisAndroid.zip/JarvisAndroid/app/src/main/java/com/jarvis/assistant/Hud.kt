package com.jarvis.assistant

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

object Hud {
    val bg = Color(0xFF05090D)
    val panel = Color(0xFF0B141B)
    val line = Color(0xFF16313D)
    val cyan = Color(0xFF5CE1F2)
    val cyanDim = Color(0xFF3C9FAE)
    val amber = Color(0xFFFFB547)
    val text = Color(0xFFD7EEF2)
    val dim = Color(0xFF7F9AA3)
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Hud.cyan, onPrimary = Hud.bg, secondary = Hud.amber,
            background = Hud.bg, surface = Hud.panel, onSurface = Hud.text, onBackground = Hud.text,
            outline = Hud.line, surfaceVariant = Hud.panel, onSurfaceVariant = Hud.dim,
        ),
        content = content,
    )
}

private fun phaseColor(p: Phase): Color = when (p) {
    Phase.IDLE -> Hud.cyanDim
    Phase.WAKE -> Hud.cyanDim
    Phase.LISTENING -> Hud.cyan
    Phase.THINKING -> Hud.amber
    Phase.SPEAKING -> Color(0xFFA8F1FF)
}

private fun phaseLabel(p: Phase): String = when (p) {
    Phase.IDLE -> "Standing by"
    Phase.WAKE -> "Waiting for \u201C${Prefs.wakeWord}\u201D"
    Phase.LISTENING -> "Listening"
    Phase.THINKING -> "Working on it"
    Phase.SPEAKING -> "Speaking"
}

/** The one memorable thing: a reactor ring that breathes at rest, swells with your voice, sweeps while thinking. */
@Composable
fun Orb(phase: Phase, level: Float, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "orb")
    val t by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "t")
    val lvl by animateFloatAsState(level, tween(90), label = "lvl")
    val color by animateColorAsState(phaseColor(phase), tween(300), label = "color")

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val tau = (2.0 * PI).toFloat()

        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.20f), Color.Transparent), center = c, radius = r),
            radius = r,
        )
        rotate(t * 360f, c) {
            drawCircle(
                color.copy(alpha = 0.35f), radius = r * 0.95f,
                style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))),
            )
        }
        val n = 72
        for (i in 0 until n) {
            val a = i.toFloat() / n * tau
            val wob = when (phase) {
                Phase.SPEAKING -> 0.5f + 0.5f * sin(t * tau * 6f + i * 0.55f) * sin(t * tau * 2f + i * 0.2f)
                Phase.LISTENING -> lvl * (0.55f + 0.45f * sin(i * 1.7f + t * tau * 8f))
                Phase.THINKING -> max(0f, sin(a * 3f - t * tau * 2f)) * 0.7f
                else -> 0.08f + 0.04f * sin(t * tau + i * 0.3f)
            }.coerceIn(0f, 1f)
            val inner = r * 0.62f
            val outer = inner + r * (0.05f + 0.24f * wob)
            drawLine(
                color,
                c + Offset(cos(a) * inner, sin(a) * inner),
                c + Offset(cos(a) * outer, sin(a) * outer),
                strokeWidth = 3f, cap = StrokeCap.Round,
            )
        }
        val breathe = 1f + 0.05f * sin(t * tau)
        val core = r * 0.5f * breathe
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.85f), color.copy(alpha = 0.5f), Color.Transparent), center = c, radius = core),
            radius = core,
        )
        drawCircle(color, radius = r * 0.55f, style = Stroke(width = 2f))
    }
}

@Composable
fun HudScreen(onSettings: () -> Unit, onAccess: () -> Unit) {
    val phase by Engine.phase.collectAsState()
    val level by Engine.level.collectAsState()
    val lines by Engine.log.collectAsState()
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) list.animateScrollToItem(lines.lastIndex) }
    val busy = phase != Phase.IDLE && phase != Phase.WAKE

    Column(Modifier.fillMaxSize().background(Hud.bg).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(Prefs.assistantName, color = Hud.text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onAccess) { Text("Access", color = Hud.cyan) }
            TextButton(onClick = onSettings) { Text("Settings", color = Hud.cyan) }
        }
        Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
            Orb(phase, level, Modifier.size(240.dp))
        }
        Text(
            phaseLabel(phase), color = phaseColor(phase), fontSize = 14.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        )
        if (lines.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (Prefs.geminiKey.isBlank()) "Add your Gemini API key in Settings to begin."
                    else "Tap Talk and speak, or type below.",
                    color = Hud.dim, fontSize = 15.sp, textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(lines) { LineRow(it) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("Type a request", color = Hud.dim) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { Engine.submit(input); input = "" }),
            )
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { if (busy) Engine.cancel() else Engine.talk() },
                shape = CircleShape, modifier = Modifier.size(58.dp), contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (busy) Hud.amber else Hud.cyan, contentColor = Hud.bg),
            ) { Text(if (busy) "Stop" else "Talk", fontSize = 13.sp, fontWeight = FontWeight.Medium) }
        }
    }
}

@Composable
private fun LineRow(l: Line) {
    val mine = l.who == "You"
    val sys = l.who == "System"
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        Text(
            l.text,
            color = if (sys) Hud.amber else Hud.text,
            fontSize = if (sys) 13.sp else 15.sp,
            modifier = Modifier.widthIn(max = 320.dp)
                .background(if (mine) Hud.panel else Color.Transparent, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
        )
    }
}

@Composable
fun ConfirmDialog() {
    val p by Confirm.pending.collectAsState()
    p?.let { pending ->
        AlertDialog(
            onDismissRequest = { Confirm.resolve(pending.id, false) },
            title = { Text("Confirm") },
            text = { Text(pending.text) },
            confirmButton = { TextButton(onClick = { Confirm.resolve(pending.id, true) }) { Text("Confirm") } },
            dismissButton = { TextButton(onClick = { Confirm.resolve(pending.id, false) }) { Text("Cancel") } },
        )
    }
}
