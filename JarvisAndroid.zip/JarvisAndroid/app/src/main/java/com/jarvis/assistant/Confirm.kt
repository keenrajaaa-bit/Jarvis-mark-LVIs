package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Irreversible actions (calls, texts, sent messages) wait for a button YOU press.
 * The token is issued by the UI or a notification button; the model cannot confirm for itself.
 */
object Confirm {
    data class Pending(val id: Int, val text: String, val result: CompletableDeferred<Boolean>)

    val pending = MutableStateFlow<Pending?>(null)
    private var seq = 0

    suspend fun ask(ctx: Context, text: String): Boolean {
        val p = Pending(++seq, text, CompletableDeferred())
        pending.value = p
        Notifier.confirm(ctx, p)
        val ok = withTimeoutOrNull(60_000) { p.result.await() } ?: false
        if (pending.value?.id == p.id) pending.value = null
        Notifier.clearConfirm(ctx)
        return ok
    }

    fun resolve(id: Int, ok: Boolean) {
        val p = pending.value ?: return
        if (p.id == id) p.result.complete(ok)
    }
}

class ConfirmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Confirm.resolve(intent.getIntExtra("id", -1), intent.getBooleanExtra("ok", false))
    }
}

object Notifier {
    const val CH_SERVICE = "jarvis_service"
    const val CH_CONFIRM = "jarvis_confirm"
    const val ID_SERVICE = 1
    const val ID_CONFIRM = 2

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Jarvis running", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_CONFIRM, "Jarvis confirmations", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    fun confirm(ctx: Context, p: Confirm.Pending) {
        fun pi(ok: Boolean): PendingIntent = PendingIntent.getBroadcast(
            ctx, p.id * 2 + (if (ok) 1 else 0),
            Intent(ctx, ConfirmReceiver::class.java).putExtra("id", p.id).putExtra("ok", ok),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CH_CONFIRM)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("Jarvis needs your OK")
            .setContentText(p.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(p.text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "Confirm", pi(true))
            .addAction(0, "Cancel", pi(false))
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_CONFIRM, n)
    }

    fun clearConfirm(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID_CONFIRM)
    }
}
