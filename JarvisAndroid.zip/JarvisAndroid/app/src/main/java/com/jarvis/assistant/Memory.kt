package com.jarvis.assistant

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Long-term memory. Nothing is silently dropped; the prompt carries a core, the rest is looked up. */
object Memory {
    private lateinit var file: File
    private val data = LinkedHashMap<String, Pair<String, Long>>()

    @Synchronized
    fun init(ctx: Context) {
        file = File(ctx.filesDir, "memory.json")
        if (file.exists()) {
            runCatching {
                val o = JSONObject(file.readText())
                for (k in o.keys()) {
                    val e = o.getJSONObject(k)
                    data[k] = e.getString("v") to e.optLong("t")
                }
            }
        }
    }

    @Synchronized
    private fun save() {
        val o = JSONObject()
        for ((k, v) in data) o.put(k, JSONObject().put("v", v.first).put("t", v.second))
        file.writeText(o.toString())
    }

    @Synchronized
    fun remember(key: String, value: String) {
        data[key.trim().lowercase().replace(' ', '_')] = value.trim() to System.currentTimeMillis()
        save()
    }

    @Synchronized
    fun forget(key: String): Boolean {
        val k = key.trim().lowercase().replace(' ', '_')
        val removed = data.remove(k) != null
        if (removed) save()
        return removed
    }

    @Synchronized
    fun search(query: String): List<String> {
        val words = query.lowercase().split(Regex("\\W+")).filter { it.length > 1 }
        return data.entries
            .filter { e -> words.isEmpty() || words.any { it in e.key || it in e.value.first.lowercase() } }
            .sortedByDescending { it.value.second }
            .take(15)
            .map { "${it.key}: ${it.value.first}" }
    }

    @Synchronized
    fun core(budget: Int = 1200): String {
        val sb = StringBuilder()
        val rest = mutableListOf<String>()
        for (e in data.entries.sortedByDescending { it.value.second }) {
            val line = "- ${e.key}: ${e.value.first}\n"
            if (sb.length + line.length <= budget) sb.append(line) else rest.add(e.key)
        }
        if (rest.isNotEmpty()) {
            sb.append("More stored keys (use recall_memory): ").append(rest.take(60).joinToString(", "))
        }
        return sb.toString().ifBlank { "(nothing stored yet)" }
    }
}
