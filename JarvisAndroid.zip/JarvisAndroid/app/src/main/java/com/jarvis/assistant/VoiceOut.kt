package com.jarvis.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/** ElevenLabs: the voice cloned from the bundled sample (res/raw/jarvis_voice_sample.mp3). */
object Eleven {
    private const val API = "https://api.elevenlabs.io/v1"
    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun synth(ctx: Context, text: String): File {
        val body = JSONObject()
            .put("text", text)
            .put("model_id", "eleven_flash_v2_5")
            .put("voice_settings", JSONObject().put("stability", 0.5).put("similarity_boost", 0.85))
            .toString().toRequestBody(JSON)
        val req = Request.Builder()
            .url("$API/text-to-speech/${Prefs.voiceId}?output_format=mp3_44100_128")
            .header("xi-api-key", Prefs.elevenKey)
            .post(body).build()
        Net.client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("ElevenLabs ${r.code}: ${r.body?.string().orEmpty().take(200)}")
            val f = File.createTempFile("tts", ".mp3", ctx.cacheDir)
            f.outputStream().use { out -> r.body!!.byteStream().copyTo(out) }
            return f
        }
    }

    /** Instant voice clone from the sample bundled in the app. Returns the new voice id. */
    fun cloneVoice(ctx: Context, name: String): String {
        val bytes = ctx.resources.openRawResource(R.raw.jarvis_voice_sample).readBytes()
        val form = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("name", name)
            .addFormDataPart("description", "Assistant voice cloned from a user-supplied sample")
            .addFormDataPart("remove_background_noise", "false")
            .addFormDataPart("files", "jarvis_voice_sample.mp3", bytes.toRequestBody("audio/mpeg".toMediaType()))
            .build()
        val req = Request.Builder().url("$API/voices/add").header("xi-api-key", Prefs.elevenKey).post(form).build()
        Net.client.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("ElevenLabs ${r.code}: ${txt.take(240)}")
            return JSONObject(txt).getString("voice_id")
        }
    }
}

/** Speaks text: ElevenLabs when configured, the phone's own voice otherwise (and as a fallback). */
class VoiceOut(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private val ready = CompletableDeferred<Boolean>()
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Unit>>()

    fun init() {
        val t = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) { applyVoice(); ready.complete(true) } else ready.complete(false)
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { waiters.remove(utteranceId)?.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { waiters.remove(utteranceId)?.complete(Unit) }
        })
        tts = t
    }

    fun applyVoice() {
        val t = tts ?: return
        val loc = Locale.forLanguageTag(Prefs.ttsLocale.ifBlank { "en-GB" })
        t.language = loc
        val all = t.voices.orEmpty().filter { it.locale.language == loc.language && !it.isNetworkConnectionRequired }
        val named = all.firstOrNull { it.name == Prefs.ttsVoiceName }
        val picked = named ?: all.firstOrNull { it.locale.country == loc.country && it.name.contains("-x-gb") && (it.name.contains("gbb") || it.name.contains("gbd")) }
            ?: all.firstOrNull { it.locale.country == loc.country }
        if (picked != null) t.voice = picked
        t.setPitch(Prefs.ttsPitch)
        t.setSpeechRate(Prefs.ttsRate)
    }

    fun voiceNames(): List<String> = tts?.voices.orEmpty().filter { !it.isNetworkConnectionRequired }.map { it.name }.sorted()

    fun stopTts() {
        tts?.stop()
        waiters.values.forEach { it.complete(Unit) }
        waiters.clear()
    }

    suspend fun speak(raw: String) {
        val sentences = split(clean(raw))
        if (sentences.isEmpty()) return
        if (Prefs.elevenReady()) {
            var played = 0
            try {
                speakEleven(sentences) { played++ }
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Engine.note("ElevenLabs failed (${e.message?.take(120)}). Using the phone's voice.")
            }
            speakTts(sentences.drop(played))
        } else {
            speakTts(sentences)
        }
    }

    private suspend fun speakEleven(sentences: List<String>, onPlayed: () -> Unit) = coroutineScope {
        val ch = Channel<File>(1)
        val producer = launch(Dispatchers.IO) {
            try {
                for (s in sentences) ch.send(Eleven.synth(ctx, s))
                ch.close()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ch.close(e)
            }
        }
        try {
            for (f in ch) { play(f); f.delete(); onPlayed() }
        } finally {
            producer.cancel()
        }
    }

    private suspend fun play(f: File) = suspendCancellableCoroutine<Unit> { cont ->
        val mp = MediaPlayer()
        mp.setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        )
        mp.setDataSource(f.absolutePath)
        mp.setOnPreparedListener { it.start() }
        mp.setOnCompletionListener { it.release(); if (cont.isActive) cont.resume(Unit) }
        mp.setOnErrorListener { m, _, _ -> m.release(); if (cont.isActive) cont.resume(Unit); true }
        cont.invokeOnCancellation { runCatching { mp.release() } }
        mp.prepareAsync()
    }

    private suspend fun speakTts(sentences: List<String>) {
        if (!ready.await()) throw IllegalStateException("The phone's text-to-speech is unavailable.")
        val t = tts ?: return
        val ids = sentences.map { s ->
            val id = UUID.randomUUID().toString()
            waiters[id] = CompletableDeferred()
            t.speak(s, TextToSpeech.QUEUE_ADD, null, id)
            id
        }
        try {
            for (id in ids) waiters[id]?.await()
        } finally {
            t.stop()
            ids.forEach { waiters.remove(it) }
        }
    }

    // Markdown, links and emoji are written for the eye; they must not reach the ear.
    private val emoji = Regex("[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}]")
    private val url = Regex("https?://\\S+")

    private fun clean(s: String): String =
        s.replace(url, "").replace(emoji, "").replace(Regex("[*_#`~>|]"), "").replace(Regex("\\s+"), " ").trim()

    private fun split(s: String): List<String> =
        s.split(Regex("(?<=[.!?。！？])\\s+")).map { it.trim() }.filter { it.isNotBlank() }
}
