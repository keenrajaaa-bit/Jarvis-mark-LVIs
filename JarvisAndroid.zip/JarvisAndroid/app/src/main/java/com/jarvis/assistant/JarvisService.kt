package com.jarvis.assistant

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Keeps Jarvis alive in the background, and listens for the wake word when hands-free is on. */
class JarvisService : Service() {
    companion object { const val ACTION_STOP = "com.jarvis.assistant.STOP" }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Engine.stopWake()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        Notifier.ensureChannels(this)
        val stop = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, Notifier.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("${Prefs.assistantName} is running")
            .setContentText(if (Prefs.handsFree) "Listening for \"${Prefs.wakeWord}\"" else "Tap to talk")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        try {
            startForeground(Notifier.ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            Engine.note("Could not start in the background: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
        if (Prefs.handsFree) Engine.startWake() else Engine.stopWake()
        return START_STICKY
    }

    override fun onDestroy() {
        Engine.stopWake()
        super.onDestroy()
    }
}
