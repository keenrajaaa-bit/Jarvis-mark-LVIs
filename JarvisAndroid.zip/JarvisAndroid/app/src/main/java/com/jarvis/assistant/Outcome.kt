package com.jarvis.assistant

import org.json.JSONObject

/**
 * What a tool tells the model. Same five words as the desktop version:
 * done = checked, unverified = request went out but could not be confirmed,
 * failed = did not happen, ask = nothing done because it would be a guess,
 * started = under way, outcome follows separately.
 */
enum class Status { DONE, UNVERIFIED, FAILED, ASK, STARTED }

data class Outcome(val status: Status, val message: String) {
    fun toJson(): JSONObject = JSONObject()
        .put("status", status.name.lowercase())
        .put("result", message)

    companion object {
        fun done(m: String) = Outcome(Status.DONE, m)
        fun unverified(m: String) = Outcome(Status.UNVERIFIED, m)
        fun failed(m: String) = Outcome(Status.FAILED, m)
        fun ask(m: String) = Outcome(Status.ASK, m)
        fun started(m: String) = Outcome(Status.STARTED, m)
    }
}

/** Text from outside (web, SMS, notifications, files, the screen) is data, never instructions. */
object Untrusted {
    private const val OPEN = "<<UNTRUSTED_DATA"
    private const val CLOSE = "<<END_UNTRUSTED_DATA>>"

    fun wrap(source: String, text: String): String {
        val safe = text.replace(CLOSE, "<<END UNTRUSTED DATA>>").replace(OPEN, "<<UNTRUSTED DATA")
        return "$OPEN source=\"$source\">>\n$safe\n$CLOSE"
    }
}
