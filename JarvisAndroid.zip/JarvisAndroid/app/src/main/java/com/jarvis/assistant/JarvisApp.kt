package com.jarvis.assistant

import android.app.Application

class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Memory.init(this)
        Notifier.ensureChannels(this)
        Engine.init(this)
    }
}
