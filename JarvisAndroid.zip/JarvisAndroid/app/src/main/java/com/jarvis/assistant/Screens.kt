package com.jarvis.assistant

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
    )
}

@Composable
private fun Section(title: String) {
    Text(title, color = Hud.cyan, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 18.dp, bottom = 2.dp))
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Hud.dim, fontSize = 13.sp)
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var gemini by remember { mutableStateOf(Prefs.geminiKey) }
    var eleven by remember { mutableStateOf(Prefs.elevenKey) }
    var voiceId by remember { mutableStateOf(Prefs.voiceId) }
    var consent by remember { mutableStateOf(false) }
    var cloning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    var userName by remember { mutableStateOf(Prefs.userName) }
    var botName by remember { mutableStateOf(Prefs.assistantName) }
    var wake by remember { mutableStateOf(Prefs.wakeWord) }
    var stt by remember { mutableStateOf(Prefs.sttLang) }
    var handsFree by remember { mutableStateOf(Prefs.handsFree) }

    var ttsLocale by remember { mutableStateOf(Prefs.ttsLocale) }
    var ttsVoice by remember { mutableStateOf(Prefs.ttsVoiceName) }
    var pitch by remember { mutableStateOf(Prefs.ttsPitch.toString()) }
    var rate by remember { mutableStateOf(Prefs.ttsRate.toString()) }

    fun save() {
        Prefs.geminiKey = gemini; Prefs.elevenKey = eleven; Prefs.voiceId = voiceId
        Prefs.userName = userName.ifBlank { "Sir" }; Prefs.assistantName = botName.ifBlank { "Jarvis" }
        Prefs.wakeWord = wake.ifBlank { "jarvis" }; Prefs.sttLang = stt
        Prefs.ttsLocale = ttsLocale; Prefs.ttsVoiceName = ttsVoice
        Prefs.ttsPitch = pitch.toFloatOrNull()?.coerceIn(0.5f, 1.5f) ?: 0.82f
        Prefs.ttsRate = rate.toFloatOrNull()?.coerceIn(0.5f, 1.5f) ?: 1.0f
        Prefs.handsFree = handsFree
        Engine.voice.applyVoice()
        startJarvis(ctx)
    }

    Column(Modifier.fillMaxSize().background(Hud.bg).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back", color = Hud.cyan) }
            Text("Settings", color = Hud.text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }

        Section("Brain")
        Field("Gemini API key", gemini, { gemini = it }, secret = true)
        Hint("Free key from aistudio.google.com/apikey. Stored encrypted on this phone.")

        Section("Voice")
        Field("ElevenLabs API key", eleven, { eleven = it }, secret = true)
        Field("Voice ID", voiceId, { voiceId = it })
        Hint("The bundled sample (res/raw/jarvis_voice_sample.mp3) can be turned into an ElevenLabs voice. Needs a plan with Instant Voice Cloning.")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = consent, onCheckedChange = { consent = it })
            Text("I own this voice or have permission to clone it.", color = Hud.text, fontSize = 13.sp)
        }
        Button(
            enabled = consent && eleven.isNotBlank() && !cloning,
            onClick = {
                cloning = true; status = "Cloning\u2026"
                scope.launch {
                    val r = runCatching { withContext(Dispatchers.IO) { Prefs.elevenKey = eleven; Eleven.cloneVoice(ctx, "Jarvis") } }
                    cloning = false
                    r.onSuccess { voiceId = it; Prefs.voiceId = it; status = "Voice cloned. Press Test voice." }
                        .onFailure { status = it.message ?: "Cloning failed." }
                }
            },
        ) { Text("Clone voice from sample") }
        OutlinedButton(onClick = { save(); Engine.say("At your service, ${Prefs.userName}. All systems are responding.") }) {
            Text("Test voice", color = Hud.cyan)
        }
        if (status.isNotBlank()) Text(status, color = Hud.amber, fontSize = 13.sp)

        Section("Phone voice (fallback)")
        Hint("Used when no ElevenLabs voice is set, or it fails. Pitch 0.82 suits a low male voice; pick a male voice in Android's text-to-speech settings for the best match.")
        Field("Language tag", ttsLocale, { ttsLocale = it })
        Field("Voice name (optional)", ttsVoice, { ttsVoice = it })
        val names = Engine.voice.voiceNames().filter { it.startsWith("en-") }.take(8)
        if (names.isNotEmpty()) Hint("Installed: " + names.joinToString(", "))
        Field("Pitch (0.5 to 1.5)", pitch, { pitch = it })
        Field("Speed (0.5 to 1.5)", rate, { rate = it })

        Section("You")
        Field("What Jarvis calls you", userName, { userName = it })
        Field("Assistant name", botName, { botName = it })
        Field("Speech recognition language (e.g. en-US, id-ID)", stt, { stt = it })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Hands-free", color = Hud.text, fontSize = 15.sp)
                Hint("Keeps the microphone open in the background and waits for the wake word. Uses battery.")
            }
            Switch(checked = handsFree, onCheckedChange = { handsFree = it })
        }
        if (handsFree) Field("Wake word", wake, { wake = it })

        Spacer(Modifier.height(8.dp))
        Button(onClick = { save(); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Save") }
        Spacer(Modifier.height(24.dp))
    }
}

private class Access(val title: String, val why: String, val on: Boolean, val grant: () -> Unit)

@Composable
fun AccessScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        startJarvis(ctx)
    }

    val runtime = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        addAll(listOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS, Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
        ))
    }
    fun open(i: Intent) { ctx.startActivity(i) }
    val pkg = Uri.parse("package:${ctx.packageName}")

    val items = remember(tick) {
        listOf(
            Access("Core permissions", "Microphone, phone, contacts, texts, calendar, location, notifications.",
                runtime.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }) {
                launcher.launch(runtime.toTypedArray())
            },
            Access("Screen control", "Lets Jarvis read the screen, tap, type, scroll and take screenshots. Needed to send WhatsApp messages, flip Wi-Fi, or describe what you are looking at.",
                JarvisAccessibility.instance != null) { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            Access("Notification access", "Lets Jarvis read incoming notifications and clear them.",
                NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
                open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            },
            Access("All files", "Lets Jarvis list, search and read files in shared storage.",
                Environment.isExternalStorageManager()) {
                open(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg))
            },
            Access("Modify system settings", "Needed to change screen brightness.",
                Settings.System.canWrite(ctx)) { open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)) },
            Access("Display over other apps", "Lets Jarvis open apps while it is in the background; without it Android may block launches.",
                Settings.canDrawOverlays(ctx)) { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) },
            Access("Do Not Disturb", "Needed to switch Do Not Disturb on and off.",
                ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted) {
                open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            },
            Access("Run in background", "Stops battery optimisation from killing hands-free mode.",
                ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)) {
                open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg))
            },
        )
    }

    Column(Modifier.fillMaxSize().background(Hud.bg).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back", color = Hud.cyan) }
            Text("Access", color = Hud.text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
        Hint("Android does not let an app give itself these. Each one opens the system page where you switch it on, and you can switch it off there at any time.")
        Column(Modifier.fillMaxWidth().background(Hud.panel, RoundedCornerShape(12.dp)).padding(12.dp)) {
            Text("Screen control or notification access greyed out?", color = Hud.amber, fontSize = 14.sp)
            Hint("Android 13 and newer block these for apps installed from outside the Play Store. Open App info, tap the three dots at the top right, choose Allow restricted settings, then try again.")
            TextButton(onClick = { open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)) }) { Text("Open App info", color = Hud.cyan) }
        }
        for (it in items) {
            Row(Modifier.fillMaxWidth().background(Hud.panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 10.dp)) {
                    Text(it.title, color = Hud.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Hint(it.why)
                }
                if (it.on) Text("On", color = Hud.cyan, fontSize = 14.sp)
                else Button(onClick = it.grant) { Text("Turn on") }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
