package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Hears one utterance with Android's own recognizer. Returns null on silence or no match. */
class SpeechIn(private val ctx: Context) {
    @Volatile var onLevel: ((Float) -> Unit)? = null

    suspend fun listenOnce(): String? = withContext(Dispatchers.Main) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Engine.note("No speech recognition service on this phone. Install or enable Google's.")
            return@withContext null
        }
        suspendCancellableCoroutine<String?> { cont ->
            val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
            var finished = false
            fun finish(v: String?) {
                if (finished) return
                finished = true
                rec.destroy()
                if (cont.isActive) cont.resume(v)
            }
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    finish(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
                }
                override fun onError(error: Int) {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) Engine.note("Microphone permission is missing.")
                    finish(null)
                }
                override fun onRmsChanged(rmsdB: Float) { onLevel?.invoke(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            if (Prefs.sttLang.isNotBlank()) i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.sttLang)
            cont.invokeOnCancellation { Handler(Looper.getMainLooper()).post { runCatching { rec.destroy() } } }
            rec.startListening(i)
        }
    }
}
