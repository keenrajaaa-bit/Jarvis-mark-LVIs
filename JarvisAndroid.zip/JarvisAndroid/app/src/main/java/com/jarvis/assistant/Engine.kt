package com.jarvis.assistant

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger

enum class Phase { IDLE, WAKE, LISTENING, THINKING, SPEAKING }

data class Line(val who: String, val text: String)

/**
 * The one assistant for the whole process. The screen, the foreground service and the
 * wake-word loop all talk to this; it owns ears, brain and voice.
 */
object Engine {
    private lateinit var app: Context
    private lateinit var brain: Brain
    private lateinit var ears: SpeechIn
    lateinit var voice: VoiceOut
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val phase = MutableStateFlow(Phase.IDLE)
    val log = MutableStateFlow<List<Line>>(emptyList())
    val level = MutableStateFlow(0f)

    @Volatile private var listening = false
    @Volatile private var thinking = false
    @Volatile private var speaking = false
    @Volatile private var wakeArmed = false

    private var turn: Job? = null
    private var wakeJob: Job? = null
    private var speechJob: Job? = null
    private val speech = Channel<String>(Channel.UNLIMITED)
    private val pendingSpeech = AtomicInteger(0)

    fun init(ctx: Context) {
        app = ctx.applicationContext
        brain = Brain(app)
        ears = SpeechIn(app).also { e ->
            e.onLevel = { raw -> level.value = level.value * 0.5f + raw * 0.5f }
        }
        voice = VoiceOut(app).also { it.init() }
        startSpeechConsumer()
    }

    private fun refresh() {
        phase.value = when {
            listening -> Phase.LISTENING
            speaking -> Phase.SPEAKING
            thinking -> Phase.THINKING
            wakeArmed -> Phase.WAKE
            else -> Phase.IDLE
        }
        if (!listening) level.value = 0f
    }

    fun note(text: String) = addLog("System", text)

    private fun addLog(who: String, text: String) {
        log.update { (it + Line(who, text)).takeLast(60) }
    }

    // ---- speech queue: sentences are spoken in order, one after another ----

    private fun startSpeechConsumer() {
        speechJob = scope.launch {
            for (t in speech) {
                speaking = true; refresh()
                try {
                    voice.speak(t)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    note("Voice failed: ${e.message?.take(120)}")
                }
                if (pendingSpeech.decrementAndGet() <= 0) { pendingSpeech.set(0); speaking = false }
                refresh()
            }
        }
    }

    fun say(text: String) {
        if (text.isBlank()) return
        pendingSpeech.incrementAndGet()
        speech.trySend(text)
    }

    fun stopSpeaking() {
        while (speech.tryReceive().isSuccess) { /* drain */ }
        speechJob?.cancel()
        voice.stopTts()
        pendingSpeech.set(0)
        speaking = false
        refresh()
        startSpeechConsumer()
    }

    private suspend fun awaitSpeech() {
        while (pendingSpeech.get() > 0) delay(100)
    }

    // ---- turns ----

    private suspend fun runTurn(text: String) {
        addLog("You", text)
        thinking = true; refresh()
        try {
            val reply = brain.respond(text) { said -> addLog(Prefs.assistantName, said); say(said) }
            if (reply.isNotBlank()) { addLog(Prefs.assistantName, reply); say(reply) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            note(e.message ?: "Something went wrong.")
            say("That didn't work. The details are in the log.")
        } finally {
            thinking = false; refresh()
        }
    }

    /** Type a request. */
    fun submit(text: String) {
        if (text.isBlank()) return
        cancel()
        turn = scope.launch { runTurn(text.trim()); awaitSpeech() }
    }

    /** Tap-to-talk: listen once, then run the request. */
    fun talk() {
        cancel()
        pauseWake()
        turn = scope.launch {
            try {
                listening = true; refresh()
                val heard = try { ears.listenOnce() } finally { listening = false; refresh() }
                if (heard.isNullOrBlank()) note("I didn't catch that.") else runTurn(heard)
                awaitSpeech()
            } finally {
                resumeWake()
            }
        }
    }

    /** Stop whatever is happening: listening, thinking or speaking. */
    fun cancel() {
        turn?.cancel()
        stopSpeaking()
        listening = false; thinking = false; refresh()
    }

    // ---- hands-free: say the wake word ----

    private var wakeWanted = false

    fun startWake() { wakeWanted = true; resumeWake() }

    fun stopWake() {
        wakeWanted = false
        wakeJob?.cancel()
        wakeArmed = false
        refresh()
    }

    private fun pauseWake() { wakeJob?.cancel(); wakeArmed = false; refresh() }

    private fun resumeWake() {
        if (!wakeWanted || wakeJob?.isActive == true) return
        wakeJob = scope.launch {
            wakeArmed = true; refresh()
            val wake = Prefs.wakeWord.ifBlank { "jarvis" }
            while (isActive) {
                if (listening || thinking || speaking) { delay(300); continue }
                val heard = ears.listenOnce()
                if (heard.isNullOrBlank()) { delay(150); continue }
                val idx = heard.lowercase().indexOf(wake)
                if (idx < 0) continue
                val rest = heard.substring(idx + wake.length).trim(' ', ',', '.', '!', '?')
                wakeArmed = false; refresh()
                if (rest.isNotBlank()) {
                    runTurn(rest)
                } else {
                    say("Yes, ${Prefs.userName}?")
                    awaitSpeech()
                    listening = true; refresh()
                    val next = try { ears.listenOnce() } finally { listening = false; refresh() }
                    if (!next.isNullOrBlank()) runTurn(next)
                }
                awaitSpeech()
                wakeArmed = true; refresh()
            }
        }
    }
}
