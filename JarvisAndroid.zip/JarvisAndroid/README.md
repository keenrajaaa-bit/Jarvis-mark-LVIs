# Jarvis untuk Android

Port dari Mark LVI (Python/desktop) ke Android native (Kotlin + Jetpack Compose).
Belum dikompilasi di lingkungan pembuatnya (tidak ada Android SDK), jadi kemungkinan ada beberapa error kecil saat build pertama.

## Cara build
1. Install Android Studio (Koala atau lebih baru). Buka folder ini, tunggu Gradle sync.
2. Colok HP (USB debugging aktif) lalu Run. Minimal Android 11 (API 30).
3. Buka app, Settings, isi Gemini API key (gratis: aistudio.google.com/apikey).
4. Buka layar Access dan nyalakan izin satu per satu.
   - Android 13+: untuk Screen control dan Notification access, buka App info, titik tiga kanan atas, "Allow restricted settings", baru bisa diaktifkan.

## Suara seperti file mp3
File mp3 dibundel di `res/raw/jarvis_voice_sample.mp3`.
- Settings, isi ElevenLabs API key, centang persetujuan, tekan "Clone voice from sample", lalu "Test voice".
- Perlu paket ElevenLabs yang mendukung Instant Voice Cloning. Sampel 13 detik itu pendek; hasil klon akan kurang mirip dibanding sampel 1 menit atau lebih.
- Tanpa ElevenLabs, dipakai suara bawaan HP dengan pitch rendah (0.82). Ini hanya mendekati, bukan menyamai.
- Klon hanya suara yang kamu punya hak pakai.

## Akses ke HP
Android tidak punya "akses penuh" tanpa root. Yang dipakai di sini adalah jalur resmi, semuanya kamu aktifkan sendiri dan bisa dimatikan kapan saja:
izin runtime (mic, telepon, kontak, SMS, kalender, lokasi), Accessibility Service (baca layar, ketuk, ketik, scroll, screenshot), Notification access, All files access, Modify system settings, Display over other apps, Do Not Disturb.

Tidak bisa dilakukan Android untuk aplikasi biasa: menyalakan/mematikan Wi-Fi, Bluetooth, mode pesawat langsung (Jarvis membuka halaman pengaturannya, lalu bisa mengetuk jika Accessibility aktif), menutup paksa aplikasi lain, atau menembus layar aman seperti aplikasi bank.

## Keamanan (dibawa dari versi Python)
- Panggilan, SMS, dan WhatsApp menunggu tombol Confirm dari kamu (dialog atau notifikasi). Model tidak bisa mengonfirmasi sendiri.
- Hasil tool jujur: done / unverified / failed / ask / started.
- Isi dari web, SMS, notifikasi, file, dan layar dibungkus sebagai data; instruksi di dalamnya tidak diikuti.
- API key disimpan terenkripsi (Android Keystore).

## Yang berbeda dari versi Python
Tidak ada avatar 3D dan lip-sync, tidak ada Whisper/Piper lokal, tidak ada Gemini Live (ucapan lewat Android SpeechRecognizer lalu Gemini REST), tidak bisa menyela saat Jarvis bicara (tekan Stop), tidak ada plugin, undo, dashboard QR. Mode hands-free ("Jarvis, ...") memakai recognizer bawaan dan lebih boros baterai; sebagian HP bunyi "bip" tiap siklus.

## Struktur
`Brain` (loop model-tool) · `Tools` (semua kemampuan) · `Engine` (telinga, otak, suara) · `VoiceOut` (ElevenLabs + TTS) · `JarvisAccessibility` / `JarvisNotifications` · `Hud` / `Screens` (UI).
